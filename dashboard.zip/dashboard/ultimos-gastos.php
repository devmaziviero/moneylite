<?php
// Conectar ao banco
include('../conexao.php');

$result = $conn->query("SELECT descricao, valor, data_cadastro FROM despesas ORDER BY data_cadastro DESC LIMIT 4");

echo "<ul class='lista-despesas'>";
while ($row = $result->fetch_assoc()) {
    echo "<li class='despesa'>";
    echo "❌ ".$row['descricao']." - R$ ".number_format($row['valor'], 2, ',', '.')." (".date('d/m/Y', strtotime($row['data_cadastro'])).")";
    echo "</li>";
}
echo "</ul>";

$conn->close();
?>
