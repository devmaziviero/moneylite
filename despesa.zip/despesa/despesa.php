<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ganhos- MoneyLite</title>
    <link rel="stylesheet" href="../dashboard/dashboard.css">
    <link rel="stylesheet" href="../geral.css">
    <link rel="stylesheet" href="despesa.css">
</head>
<body>
    <div class="navbar">
        <div>
            
            <div class="options-menu">
                <div class="line"></div>
                <a href="../dashboard/dashboard.php">DashBoards</a>
                <a href="../ganhos/ganhos.php">Ganhos</a>
                <a href="despesa.php">Despesas</a>
                <a href="../metas/metas.php">Metas</a>
            </div>
        </div>
        <div class="line"></div>
        <div class="bot">
            <a href="../index.php">Sair</a>
        </div>
    </div>
    <div class="main-dash">
        <div class="top">
            <h1>MoneyLite</h1>
        </div>
        <div class="main-ganhos">
            <div class="top-ganhos">
                <h1>Controle de Despesa</h1>
            </div>
            <form method="POST" action="despesa.php">
                <div class="filtros-ganhos">
                    <div class="card-filter">
                        <label for="cod-despesa">Código Despesa:</label>
                        <input type="text" name="cod-despesa" id="cod-despesa">
                    </div>

                    <div class="card-filter">
                        <label for="desc-despesa">Descrição Despesa:</label>
                        <input type="text" name="desc-despesa" id="desc-despesa">
                    </div>

                    <div class="card-filter">
                        <label for="valor-despesa">Ranges Valores Despesa:</label>
                        <select name="valor-despesa" id="valor-despesa">
                            <option value="">Todos</option>
                            <option value="abaixo_100">abaixo de 100</option>
                            <option value="entre_100_200">entre 100 e 200</option>
                            <option value="entre_200_500">entre 200 e 500</option>
                            <option value="acima_500">acima de 500</option>
                        </select>
                    </div>

                    <div class="card-filter">
                        <label for="data-despesa">Dt Cadastro Despesa:</label>
                        <input type="date" name="data-despesa" id="data-despesa">
                    </div>

                    <div class="pesquisa">
                        <button type="submit">Pesquisar</button>
                    </div>
                </div>
            </form>

            <div class="lista-ganhos">
                <table border="1">
                    <thead>
                        <tr>
                            <th>Código Despesa</th>
                            <th>Descrição Despesa:</th>
                            <th>Categoria</th>
                            <th>Valor Despesa</th>
                            <th>Data Cadastro</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                            // Se clicaram no botão Excluir
                            if (isset($_GET['excluir'])) {
                                $idExcluir = intval($_GET['excluir']); // Proteção: só inteiro

                                
                                // Conectar ao banco
                                include('../conexao.php');

                                // Comando para excluir a despesa
                                $sqlExcluir = "DELETE FROM despesas WHERE id_despesa = ?";
                                $stmt = $conn->prepare($sqlExcluir);
                                $stmt->bind_param("i", $idExcluir);

                                if ($stmt->execute()) {
                                    echo "<script>alert('Despesa excluída com sucesso!'); window.location.href='despesa.php';</script>";
                                } else {
                                    echo "<script>alert('Erro ao excluir despesa!'); window.location.href='despesa.php';</script>";
                                }

                                $stmt->close();
                                $conn->close();
                                exit(); // Termina aqui para não continuar rodando o restante da página
                            }
                        ?>
                        <?php
                        // Conectar ao banco
                        include('../conexao.php');


                        // Receber filtros
                        $codDespesa = $_POST['cod-despesa'] ?? '';
                        $descDespesa = $_POST['desc-despesa'] ?? '';
                        $valorDespesa = $_POST['valor-despesa'] ?? '';
                        $dataDespesa = $_POST['data-despesa'] ?? '';

                        // Montar consulta base
                        $sql = "SELECT * FROM despesas WHERE 1=1";

                        // Adicionar filtros dinamicamente
                        if (!empty($codDespesa)) {
                            $sql .= " AND id_despesa = '$codDespesa'";
                        }
                        if (!empty($descDespesa)) {
                            $sql .= " AND descricao LIKE '%$descDespesa%'";
                        }
                        if (!empty($valorDespesa)) {
                            if ($valorDespesa == "abaixo_100") {
                                $sql .= " AND valor < 100";
                            } elseif ($valorDespesa == "entre_100_200") {
                                $sql .= " AND valor BETWEEN 100 AND 200";
                            } elseif ($valorDespesa == "entre_200_500") {
                                $sql .= " AND valor BETWEEN 200 AND 500";
                            } elseif ($valorDespesa == "acima_500") {
                                $sql .= " AND valor > 500";
                            }
                        }
                        if (!empty($dataDespesa)) {
                            $sql .= " AND DATE(data_cadastro) = '$dataDespesa'";
                        }

                        // Executar consulta
                        $result = $conn->query($sql);

                        // Mostrar despesas na tabela
                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>".$row['id_despesa']."</td>";
                                echo "<td>".$row['descricao']."</td>";
                                echo "<td>".$row['categoria']."</td>";
                                echo "<td>R$ ".number_format($row['valor'], 2, ',', '.')."</td>";
                                echo "<td>".date('d/m/Y', strtotime($row['data_cadastro']))."</td>";
                                echo "<td>
                                        <a href='alterar-despesa.php?id=".$row['id_despesa']."'>Alterar</a> |
                                        <a href='despesa.php?excluir=".$row['id_despesa']."' onclick=\"return confirm('Tem certeza que deseja excluir?')\">Excluir</a>
                                    </td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='6'>Nenhuma despesa encontrada.</td></tr>";
                        }

                        $conn->close();
                        ?>
                    </tbody>

                </table>
            </div>
        </div>
        <div class="inclusao">
            <button onclick="window.location.href='incluir-despesa.php'">Incluir Nova Despesa</button>
        </div>
        </div>
    </div>
</body>
</html>